import pyautogui, keyboard, time, requests, os, json, sys, traceback
from PIL import Image

print("Supported resolutions are: 1920*1080 and 1600*900")
inputres = input("Whats your screen resolution?: ")
inputtb = input("Is your Taskbar Enabled? (Yes/No): ")

if inputres == '1920*1080' and inputtb == "Yes":
    dmcaptchapos = (35,155)
    dmcaptchacol = 70, 178, 239
    chatcaptchapos = (485,995)
    chatcaptchapos = 255, 204, 77
if inputres == '1920*1080' and inputtb == "No":
    dmcaptchapos = (35,115)
    dmcaptchacol = 70, 178, 239
    chatcaptchapos = (485,955)
    chatcaptchacol = 255, 204, 77
if inputres == '1600*900' and inputtb == "Yes":
    dmcaptchapos = (30,90)
    dmcaptchacol = 71, 179, 240
    chatcaptchapos = (390,800)
    chatcaptchacol = 255, 204, 77
if inputres == '1600*900' and inputtb == "No":
    dmcaptchapos = (30,90)
    dmcaptchacol = 71, 179, 240
    chatcaptchapos = (390,760)
    chatcaptchacol = 255, 204, 77
print(dmcaptchapos, dmcaptchacol, chatcaptchapos, chatcaptchapos)

currentpath = os.path.dirname(sys.argv[0])

with open(f"{currentpath}\config.json") as config:
    cfg = json.load(config)

data = {
"content" : f"<@{cfg['userid']}> started the Script."
}

result = requests.post(cfg['scriptstartpingwebhook'], json = data)
try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print('Error')

while True:
    try:
        if keyboard.is_pressed(cfg['startbutton']):
            while True:
                screenshot = pyautogui.screenshot()
                screenshot.save(f"{currentpath}\BHSTempScreenshot.png")
                img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                colors = img.getpixel(dmcaptchapos)

                if colors == (dmcaptchacol):
                    data = {
                    "content" : f"<@{cfg['userid']}> Attention Captcha!"
                    }
                    result = requests.post(cfg['captchapingwebhook'], json = data)
                    try:
                        result.raise_for_status()
                    except requests.exceptions.HTTPError as err:
                        print('Error')
                    time.sleep(int(cfg['captchatime']))

                else:
                    screenshot = pyautogui.screenshot()
                    screenshot.save((f"{currentpath}\BHSTempScreenshot.png"))
                    img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                    colors = img.getpixel(chatcaptchapos)

                    if colors == (chatcaptchacol):
                        data = {
                        "content" : f"<@{cfg['userid']}> Attention Captcha!"
                        }

                        result = requests.post(cfg['captchapingwebhook'], json = data)
                        try:
                            result.raise_for_status()
                        except requests.exceptions.HTTPError as err:
                            print('Error')
                        time.sleep(int(cfg['captchatime']))

                    else:
                        pyautogui.write('owo hunt')
                        pyautogui.press('enter')
                        time.sleep(1)
                        pyautogui.write(f"owo {cfg['mode']} all")
                        pyautogui.press('enter')
                        time.sleep(1)
                        time.sleep(13)

    except Exception as e:
        print(traceback.format_exc())
