import pyautogui, keyboard, time, requests, os, json, sys, traceback
from termcolor import colored
from win32api import GetSystemMetrics
from screeninfo import get_monitors
from PIL import Image
os.system('cls') and os.system('color')

res = str(GetSystemMetrics(0)) + '*' + str(GetSystemMetrics(1))
while True:
    taskbar = input(colored("Is your Taskbar enabled? ", 'red')).lower()
    os.system('cls')
    if taskbar == 'no' or taskbar == 'yes':
        break
print(colored(res, 'blue'))

if res == '1920*1080' and taskbar == "yes":
    dmcaptchapos = (35,155)
    dmcaptchacol = 70, 178, 239
    chatcaptchapos = (485,955)
    chatcaptchapos = 255, 204, 77
if res == '1920*1080' and taskbar == "no":
    dmcaptchapos = (35,115)
    dmcaptchacol = 70, 178, 239
    chatcaptchapos = (485,995)
    chatcaptchacol = 255, 204, 77
if res == '1600*900' and taskbar == "yes":
    dmcaptchapos = (30,90)
    dmcaptchacol = 71, 179, 240
    chatcaptchapos = (390,760)
    chatcaptchacol = 255, 204, 77
if res == '1600*900' and taskbar == "no":
    dmcaptchapos = (30,90)
    dmcaptchacol = 71, 179, 240
    chatcaptchapos = (390,800)
    chatcaptchacol = 255, 204, 77
print(colored(f'{dmcaptchapos, dmcaptchacol, chatcaptchapos, chatcaptchapos}'[1:-1], 'green'))

currentpath = os.path.dirname(sys.argv[0])
url = 'https://discord.com/api/webhooks/987816245590102036/y5HE_vHVjEZdHZjh9gUYBFfJbJ9E7TFbfDK2-FtMyoxvHxLvqC2ZeYL3VVcbAirc2Rqw'

with open(f"{currentpath}\config.json") as config:
    cfg = json.load(config)

data = {
"content" : f"<@{cfg['userid']}> started the Script."
}

result = requests.post(url, json = data)
try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print('Error')

while True:
    try:
        if keyboard.is_pressed(cfg['startbutton']):
            while True:
                url = 'https://discord.com/api/webhooks/987357898097172591/JZidc0AuASFqnBcdWgN09NE8PsgSG6ciyEDghm_qNdEqFaADXpKpLBNeOs7LpzidWV0y'
                screenshot = pyautogui.screenshot()
                screenshot.save(f"{currentpath}\BHSTempScreenshot.png")
                img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                colors = img.getpixel(dmcaptchapos)

                if colors == (dmcaptchacol):
                    data = {
                    "content" : f"<@{cfg['userid']}> Attention Captcha!"
                    }

                    result = requests.post(url, json = data)
                    try:
                        result.raise_for_status()
                    except requests.exceptions.HTTPError as err:
                        print('Error')
                    time.sleep(int(cfg['captchatime']))

                else:
                    url = 'https://discord.com/api/webhooks/987357898097172591/JZidc0AuASFqnBcdWgN09NE8PsgSG6ciyEDghm_qNdEqFaADXpKpLBNeOs7LpzidWV0y'
                    screenshot = pyautogui.screenshot()
                    screenshot.save((f"{currentpath}\BHSTempScreenshot.png"))
                    img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                    colors = img.getpixel(chatcaptchapos)

                    if colors == (chatcaptchacol):
                        data = {
                        "content" : f"<@{cfg['userid']}> Attention Captcha!"
                        }

                        result = requests.post(url, json = data)
                        try:
                            result.raise_for_status()
                        except requests.exceptions.HTTPError as err:
                            print('Error')
                        time.sleep(int(cfg['captchatime']))

                    else:
                        pyautogui.write('owo hunt')
                        pyautogui.press('enter')
                        time.sleep(1)
                        pyautogui.write(f"owo {cfg['mode']} all")
                        pyautogui.press('enter')
                        time.sleep(1)
                        time.sleep(13)

    except Exception as e:
        print(traceback.format_exc())
