pip install pyautogui
pip install keyboard
pip install requests
pip install os
pip install pillow