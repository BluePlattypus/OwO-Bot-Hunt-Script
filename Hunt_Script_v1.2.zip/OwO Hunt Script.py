import pyautogui, keyboard, time, requests, os, json, sys
from PIL import Image

currentpath = os.path.dirname(sys.argv[0])
url = 'https://discord.com/api/webhooks/987816245590102036/y5HE_vHVjEZdHZjh9gUYBFfJbJ9E7TFbfDK2-FtMyoxvHxLvqC2ZeYL3VVcbAirc2Rqw'

with open(f"{currentpath}\config.json") as config:
    cfg = json.load(config)

data = {
"content" : f"<@{cfg['userid']}> started the Script."
}

result = requests.post(url, json = data)
try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print('Error')
time.sleep(30)

while True:
    try:
        if keyboard.is_pressed(cfg['startbutton']):
            while True:
                url = 'https://discord.com/api/webhooks/987357898097172591/JZidc0AuASFqnBcdWgN09NE8PsgSG6ciyEDghm_qNdEqFaADXpKpLBNeOs7LpzidWV0y'
                screenshot = pyautogui.screenshot()
                screenshot.save(f"{currentpath}\BHSTempScreenshot.png")
                img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                colors = img.getpixel((35,115))

                if colors == (70, 178, 239):
                    data = {
                    "content" : f"<@{cfg['userid']}> Attention Captcha!"
                    }

                    result = requests.post(url, json = data)
                    try:
                        result.raise_for_status()
                    except requests.exceptions.HTTPError as err:
                        print('Error')
                    time.sleep(int(cfg['captchatime']))

                else:
                    url = 'https://discord.com/api/webhooks/987357898097172591/JZidc0AuASFqnBcdWgN09NE8PsgSG6ciyEDghm_qNdEqFaADXpKpLBNeOs7LpzidWV0y'
                    screenshot = pyautogui.screenshot()
                    screenshot.save((f"{currentpath}\BHSTempScreenshot.png"))
                    img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                    colors = img.getpixel((485,955))

                    if colors == (255, 204, 77):
                        data = {
                        "content" : f"<@{cfg['userid']}> Attention Captcha!"
                        }

                        result = requests.post(url, json = data)
                        try:
                            result.raise_for_status()
                        except requests.exceptions.HTTPError as err:
                            print('Error')
                        time.sleep(int(cfg['captchatime']))

                    else:
                        pyautogui.write('owo hunt')
                        pyautogui.press('enter')
                        time.sleep(1)
                        pyautogui.write(f"owo {cfg['mode']} all")
                        pyautogui.press('enter')
                        time.sleep(14)

    except Exception as e:
        print(e)
