import pyautogui, keyboard, time, requests, os, json, sys, traceback, clipboard, re, win32api, pyperclip
from win32api import GetSystemMetrics
from termcolor import colored
from screeninfo import get_monitors
from PIL import Image
os.system('cls') and os.system('color')
res = str(GetSystemMetrics(0)) + '*' + str(GetSystemMetrics(1))
while True:
    taskbar = input(colored("Is your Taskbar enabled? ", 'blue')).lower()
    os.system('cls')
    if taskbar == 'no' or taskbar == 'yes':
        lang = input(colored("Whats your Keyboard Layout? (ger and eng are supported) ", 'blue')).lower()
        os.system('cls')
        if lang == 'eng' or taskbar == 'ger':
            print('Valid option.')
    break


if res == '1920*1080' and taskbar == "yes":
    dmcaptchapos = (35,155)
    dmcaptchacol = 70, 178, 239
    chatcaptchapos = (485,955)
    chatcaptchapos = 255, 204, 77
    backupmoneystartpos = 735, 930
    backupmoneyendpos = 790, 930
    sendpos = 430, 990
if res == '1920*1080' and taskbar == "no":
    dmcaptchapos = (35,115)
    dmcaptchacol = 70, 178, 239
    chatcaptchapos = (485,995)
    chatcaptchacol = 255, 204, 77
    backupmoneystartpos = 735, 970
    backupmoneyendpos = 790, 970
    sendpos = 430, 1030
if res == '1600*900' and taskbar == "yes":
    dmcaptchapos = (30,90)
    dmcaptchacol = 71, 179, 240
    chatcaptchapos = (390,760)
    chatcaptchacol = 255, 204, 77
    backupmoneystartpos = 670, 755
    backupmoneyendpos = 720, 755
    sendpos = 390, 810
if res == '1600*900' and taskbar == "no":
    dmcaptchapos = (30,90)
    dmcaptchacol = 71, 179, 240
    chatcaptchapos = (390,800)
    chatcaptchacol = 255, 204, 77
    backupmoneystartpos = 670, 795
    backupmoneyendpos = 720, 795
    sendpos = 390, 850
if lang == 'ger':
    def _keyDown(key):
        if key not in keyboardMapping or keyboardMapping[key] is None: return
        needsShift = pyautogui.isShiftCharacter(key)
        if key == '#': needsShift = False
        if key == '+': needsShift = False
        if key == '<': needsShift = False
        print("Pyautogui Key config patch was applied.")
if lang == 'eng':
    print("No Pyautogui Key config changes were made.")

currentpath = os.path.dirname(sys.argv[0])
url = 'https://discord.com/api/webhooks/987816245590102036/y5HE_vHVjEZdHZjh9gUYBFfJbJ9E7TFbfDK2-FtMyoxvHxLvqC2ZeYL3VVcbAirc2Rqw'

with open(f"{currentpath}\config.json") as config:
    cfg = json.load(config)

data = {
"content" : f"<@{cfg['pinguseraccid']}> started the Script."
}

result = requests.post(url, json = data)
try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print('Error')

while True:
    try:
        if keyboard.is_pressed(cfg['startbutton']):
            while True:
                url = 'https://discord.com/api/webhooks/987357898097172591/JZidc0AuASFqnBcdWgN09NE8PsgSG6ciyEDghm_qNdEqFaADXpKpLBNeOs7LpzidWV0y'
                screenshot = pyautogui.screenshot()
                screenshot.save(f"{currentpath}\BHSTempScreenshot.png")
                img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                colors = img.getpixel(dmcaptchapos)

                if colors == (dmcaptchacol):
                    data = {
                    "content" : f"<@{cfg['pinguseraccid']}> Attention Captcha!"
                    }

                    result = requests.post(url, json = data)
                    try:
                        result.raise_for_status()
                    except requests.exceptions.HTTPError as err:
                        print('Error')
                        time.sleep(int(cfg['captchatime']))

                else:
                    url = 'https://discord.com/api/webhooks/987357898097172591/JZidc0AuASFqnBcdWgN09NE8PsgSG6ciyEDghm_qNdEqFaADXpKpLBNeOs7LpzidWV0y'
                    screenshot = pyautogui.screenshot()
                    screenshot.save((f"{currentpath}\BHSTempScreenshot.png"))
                    img = Image.open(f"{currentpath}\BHSTempScreenshot.png")
                    colors = img.getpixel(chatcaptchapos)

                    if colors == (chatcaptchacol):
                        data = {
                        "content" : f"<@{cfg['pinguseraccid']}> Attention Captcha!"
                        }

                        result = requests.post(url, json = data)
                        try:
                            result.raise_for_status()
                        except requests.exceptions.HTTPError as err:
                            print('Error')
                            time.sleep(int(cfg['captchatime']))

                    else:
                        pyautogui.write('owo hunt')
                        pyautogui.press('enter')
                        time.sleep(1)
                        pyautogui.write(f"owo {cfg['mode']} all")
                        pyautogui.press('enter')
                        time.sleep(1)
                        pyautogui.write('owo cash')
                        pyautogui.press('enter')
                        time.sleep(2)
                        pyautogui.moveTo(backupmoneystartpos)
                        pyautogui.mouseDown()
                        pyautogui.moveTo(backupmoneyendpos)
                        pyautogui.mouseUp()
                        pyautogui.hotkey('ctrl', 'c')
                        b1 = clipboard.paste()
                        b2 = re.sub("[^0-9]", "", b1)
                        if int(b2) > 3000:
                            balance = int(b2) - 3000
                            if lang == 'ger':
                                pyautogui.write("owo give ")
                                pyperclip.copy("<")
                                pyautogui.hotkey("ctrl", "v")
                                pyautogui.hotkey('altright', 'q')
                                pyautogui.moveTo(sendpos)
                                pyautogui.click()
                                pyautogui.write(f"{cfg['backupbankaccid']}> {balance}")
                                time.sleep(11)
                            if lang == 'eng':
                                pyautogui.write(f"owo give <@{cfg['backupbankaccid']}> {balance}")
                                pyautogui.moveTo(sendpos)
                                pyautogui.click()
                                time.sleep(11)
                        else:
                            time.sleep(11)

    except Exception as e:
        print(traceback.format_exc())
